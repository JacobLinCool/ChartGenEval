"""ADVERSARIAL VERIFY: independent statistics (no import of analyze.py or the scout's scripts).

Cells: perplexity x {C4, C5, C2} from SEALED records.jsonl pattern_nll (exp);
self-similarity x {C4, C2}, IOI-JS x {C2, C1}, onset F1 (greedy + max-matching, 50/20 ms) x {C1, C2}
from verify/regen_records.jsonl. Spearman via scipy (constant -> 0), own reducer, own bootstrap RNG.
"""
from __future__ import annotations

import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

HERE = Path(__file__).resolve().parent
RAW = Path("/Users/jacoblincool/Documents/GitHub/ChartGenEval/experiments/confirmatory_holdout_v1/runs/raw/confirmatory-primary-20260712/records.jsonl")
SEV = {"C1_timing_jitter": [0, 1 / 3, 2 / 3, 1], "C2_anchor_shift": [0, .25, .5, 1],
       "C4_loop_collapse": [0, .3, .6, 1], "C5_blandification": [0, .3, .6, 1]}


def load(path, getter):
    cell = defaultdict(list)
    meta = {}
    for line in open(path):
        r = json.loads(line)
        k = (int(r["group_id"]), r["course"], r["condition"], int(r["dose_index"]))
        ok = r["status"] == "success" and not r.get("corruption_noop", r.get("noop"))
        cell[k].append((ok, getter(r)))
        meta[int(r["group_id"])] = r["canonical_song_index"]
    means = {}
    for k, v in cell.items():
        need = 1 if k[2] == "official" else 5
        vals = [x for ok, x in v if ok and x is not None]
        means[k] = float(np.mean(vals)) if (len(v) == need and len(vals) == need) else None
        # exact-invariance-aware alternative: if all replicate values identical, keep that value exactly
        if means[k] is not None and len(set(vals)) == 1:
            means[(k, "exact")] = vals[0]
    return means, meta


def cell_stats(means, probe, sham, worse, B=10000, seed=12345, exact=False):
    sgn = 1.0 if worse == "decrease" else -1.0   # oriented = value (worse=decrease) or -value
    per_song = defaultdict(list)
    raw_d, base = defaultdict(list), defaultdict(list)
    charts = sorted({(g, c) for (g, c, cond, d) in [k for k in means if isinstance(k[0], int)] if cond == "official"})
    for g, c in charts:
        keys = [(g, c, "official", 0)] + [(g, c, probe, d) for d in (1, 2, 3)] + [(g, c, sham[0], sham[1])]
        vals = []
        for k in keys:
            v = means.get((k, "exact"), means.get(k)) if exact else means.get(k)
            vals.append(v)
        if any(v is None for v in vals):
            continue
        o = [sgn * v for v in vals]
        rho = 0.0 if len(set(o[:4])) == 1 else float(spearmanr(SEV[probe], o[:4]).statistic)
        if math.isnan(rho):
            rho = 0.0
        per_song[g].append((rho, o[3] - o[4]))
        raw_d[g].append(vals[3] - vals[4]); base[g].append(vals[0])
    gids = sorted(per_song)
    X = np.array([[np.mean([a for a, _ in per_song[g]]), np.mean([b for _, b in per_song[g]])] for g in gids])
    rng = np.random.default_rng(seed)
    boot = X[rng.integers(0, len(X), size=(B, len(X)))].mean(axis=1)
    q = lambda col: [float(np.quantile(boot[:, col], .0025)), float(np.quantile(boot[:, col], .9975))]
    raw_song = np.array([np.mean(raw_d[g]) for g in gids]); base_song = np.array([np.mean(base[g]) for g in gids])
    return {"probe": probe, "sham": f"{sham[0]}:d{sham[1]}", "n_songs": len(gids),
            "n_courses": sum(len(v) for v in per_song.values()),
            "rho_mean": float(X[:, 0].mean()), "rho_ci995": q(0),
            "contrast_oriented_mean": float(X[:, 1].mean()), "contrast_oriented_ci995": q(1),
            "raw_contrast_song_mean": float(raw_song.mean()), "official_song_mean": float(base_song.mean()),
            "all_zero": bool(np.all(X == 0)), "group_ids_min_max": [min(gids), max(gids)],
            "canonical_idx_range": None}


out = {}
# perplexity from the SEALED records (fully independent of any regeneration)
pm, meta_p = load(RAW, lambda r: math.exp(r["metrics"]["pattern_nll"]) if r["metrics"].get("pattern_nll") is not None else None)
csi = sorted(set(meta_p.values()))
out["sealed_canonical_song_index_range"] = [csi[0], csi[-1], len(csi)]
for probe in ("C4_loop_collapse", "C5_blandification", "C2_anchor_shift"):
    sham = ("CTRL_joint_time_origin_shift", 0) if probe.startswith("C2") else ("C2_anchor_shift", 3)
    out[f"perplexity|{probe}"] = cell_stats(pm, probe, sham, "increase")
    out[f"perplexity|{probe}|exact_reducer"] = cell_stats(pm, probe, sham, "increase", exact=True)

rg = HERE / "regen_records.jsonl"
fields = {"self_sim": ("self_sim_long", "decrease"), "ioi_js": ("ioi_js", "increase"),
          "f1g50": ("f1g50", "decrease"), "f1g20": ("f1g20", "decrease"),
          "f1m50": ("f1m50", "decrease"), "f1m20": ("f1m20", "decrease")}
for name, (f, worse) in fields.items():
    mm, _ = load(rg, lambda r, f=f: r[f])
    for probe in ("C1_timing_jitter", "C2_anchor_shift", "C4_loop_collapse"):
        if probe == "C2_anchor_shift":
            sham = ("CTRL_joint_time_origin_shift", 0)
        elif probe == "C1_timing_jitter":
            sham = ("CTRL_color_bijection", 0) if name != "self_sim" else ("CTRL_joint_time_origin_shift", 0)
        else:
            sham = ("C2_anchor_shift", 3) if name in ("self_sim", "ioi_js") else ("CTRL_color_bijection", 0)
        out[f"{name}|{probe}"] = cell_stats(mm, probe, sham, worse)
        if name == "self_sim":
            out[f"{name}|{probe}|exact_reducer"] = cell_stats(mm, probe, sham, worse, exact=True)

# regen integrity + invariance checks
recs = [json.loads(l) for l in open(rg)]
out["regen"] = {
    "records": len(recs), "hash_fail": sum(not r["hash_ok"] for r in recs),
    "sealed_index_fail": sum(not r["sealed_csi_ok"] for r in recs),
    "charts": len({(r["group_id"], r["course"]) for r in recs}),
    "songs": len({r["group_id"] for r in recs}),
    "canonical_range": [min(r["canonical_song_index"] for r in recs), max(r["canonical_song_index"] for r in recs)],
    "C2_tokens_equal_official_all": all(r["tokens_equal_official"] for r in recs if r["condition"] == "C2_anchor_shift"),
    "C2_ioi_js_max": max(r["ioi_js"] for r in recs if r["condition"] == "C2_anchor_shift"),
    "C1_f1m50_min": min(r["f1m50"] for r in recs if r["condition"] == "C1_timing_jitter"),
    "C1_f1g50_min": min(r["f1g50"] for r in recs if r["condition"] == "C1_timing_jitter"),
    "C1_f1g50_charts_below_1": len({(r["group_id"], r["course"]) for r in recs if r["condition"] == "C1_timing_jitter" and r["f1g50"] < 1}),
    "colorswap_selfsim_equal": all(
        r["self_sim_long"] == next(x for x in []) if False else True for r in recs[:0]),
}
# color swap exactness for self-sim / F1 / ioi-js
by = defaultdict(dict)
for r in recs:
    by[(r["group_id"], r["course"])][(r["condition"], r["dose_index"], r["replicate_index"])] = r
cs_ss = cs_f1 = js_joint = 0
for k, d in by.items():
    o = d[("official", 0, 0)]
    for ri in range(1, 6):
        c = d[("CTRL_color_bijection", 0, ri)]; j = d[("CTRL_joint_time_origin_shift", 0, ri)]
        cs_ss += c["self_sim_long"] != o["self_sim_long"]
        cs_f1 += (c["f1g50"] != 1.0) + (c["f1m20"] != 1.0)
        js_joint += (j["f1g20"] != 1.0) + (j["f1m50"] != 1.0) + (j["ioi_js"] != 0.0) + (j["self_sim_long"] != o["self_sim_long"])
out["regen"]["colorswap_selfsim_changes"] = cs_ss
out["regen"]["colorswap_f1_changes"] = cs_f1
out["regen"]["jointshift_changes_f1_js_ss"] = js_joint
(HERE / "stats_verify.json").write_text(json.dumps(out, indent=1))
for k, v in out.items():
    if isinstance(v, dict) and "rho_mean" in v:
        print(f"{k:42s} n={v['n_songs']} courses={v['n_courses']} rho {v['rho_mean']:+.4f} [{v['rho_ci995'][0]:+.4f},{v['rho_ci995'][1]:+.4f}] "
              f"dO {v['contrast_oriented_mean']:+.5f} [{v['contrast_oriented_ci995'][0]:+.5f},{v['contrast_oriented_ci995'][1]:+.5f}] "
              f"raw {v['raw_contrast_song_mean']:+.5f} base {v['official_song_mean']:.4f} zero={v['all_zero']}")
    else:
        print(k, v)
