"""Split check (held-out ids only, disjoint from dev and train) + per-dose F1 means (verify)."""
import json, glob
from collections import defaultdict
from pathlib import Path
import numpy as np, pyarrow.parquet as pq
D = Path.home()/".cache/huggingface/hub/datasets--JacobLinCool--taiko-1000-parsed-clean/snapshots/b72da4616d643018e81f372cea06ce51349285e0/data"
test = []
for f in sorted(D.glob("test-*.parquet")):
    test += pq.read_table(f, columns=["canonical","group_id","audio_sha256"]).to_pylist()
canon = [r for r in test if r["canonical"]]
dev = {r["group_id"] for r in canon[:40]}; held = {r["group_id"] for r in canon[40:120]}
train = []
for f in sorted(D.glob("train-*.parquet")):
    train += pq.read_table(f, columns=["group_id","audio_sha256"]).to_pylist()
tg = {r["group_id"] for r in train}; ta = {r["audio_sha256"] for r in train}
held_audio = {r["audio_sha256"] for r in test if r["group_id"] in held}
regen = [json.loads(l) for l in open(Path(__file__).parent/"regen_records.jsonl")]
base = Path("/private/tmp/claude-501/-Users-jacoblincool-Documents-GitHub-TCRG-RA-Workspaces/589e73c8-e622-4449-abb7-2ebb940bedba/scratchpad/cge_baselines")
scout_g = set()
for p in glob.glob(str(base/"full/shard_*.jsonl")):
    for l in open(p):
        scout_g.add(int(json.loads(l)["sid"].split("_")[1]))
out = {"n_dev": len(dev), "n_held": len(held), "dev_held_overlap": len(dev & held),
       "held_in_train_group": len(held & tg), "held_audio_in_train": len(held_audio & ta),
       "regen_groups_equal_held": {r["group_id"] for r in regen} == held,
       "scout_shard_groups_equal_held": scout_g == held}
# per-dose chart-mean F1 (song-averaged) under C1 and C2
cell = defaultdict(list)
for r in regen:
    if r["condition"] in ("C1_timing_jitter", "C2_anchor_shift"):
        for f in ("f1g50", "f1m50", "f1g20", "f1m20"):
            cell[(r["condition"], r["dose_index"], f, r["group_id"])].append(r[f])
tab = {}
for cond in ("C1_timing_jitter", "C2_anchor_shift"):
    for f in ("f1g50", "f1m50", "f1g20", "f1m20"):
        row = []
        for d in (1, 2, 3):
            song = [np.mean(v) for (c, dd, ff, g), v in cell.items() if c == cond and dd == d and ff == f]
            row.append(round(float(np.mean(song)), 5))
        tab[f"{cond}|{f}"] = row
        # fraction of charts with F1 exactly 1 at each dose
out["per_dose_song_mean_F1 (d1,d2,d3)"] = tab
frac1 = {}
for cond in ("C1_timing_jitter", "C2_anchor_shift"):
    for d in (1, 2, 3):
        rs = [r for r in regen if r["condition"] == cond and r["dose_index"] == d]
        frac1[f"{cond}|d{d}|f1m50==1"] = round(float(np.mean([r["f1m50"] == 1.0 for r in rs])), 4)
out["fraction_replicates_F1m50_exactly_1"] = frac1
print(json.dumps(out, indent=1))
(Path(__file__).parent/"split_and_dose_check.json").write_text(json.dumps(out, indent=1))
