"""Independent self-similarity (own vectorised implementation) under C5, variants regenerated with the frozen LM and hash-checked."""
import json, sys
from collections import defaultdict
from pathlib import Path
import numpy as np, pyarrow.parquet as pq
from scipy.stats import spearmanr
sys.path.insert(0, str(Path(__file__).parent))
from regen_verify import self_sim_long, FR, sorted_hits, event_tokens, apply_probe, DATA, RAW
from chartgeneval.metrics.common import NGramModel
COLS = ["group_id", "canonical", "easy", "normal", "hard", "oni", "ura"]
lm = NGramModel(order=3, alpha=0.05)
for f in sorted(DATA.glob("train-*.parquet")):
    for row in pq.read_table(f, columns=COLS).to_pylist():
        for course, chart, _ in FR._official_charts(row):
            lm.add(course, event_tokens(chart.events, chart.bpm))
assert FR._lm_state_fingerprint(lm).startswith("07b82322")
sealed = {}
for l in open(RAW):
    r = json.loads(l)
    if r["condition"] == "C5_blandification" and r["replicate_index"] == 1:
        sealed[r["task_id"]] = (r["variant_events_sha256"], r["status"] == "success" and not r["corruption_noop"])
test = []
for f in sorted(DATA.glob("test-*.parquet")):
    test += pq.read_table(f, columns=COLS).to_pylist()
song = defaultdict(list); hf = 0; offs = []; d3s = []
for row in [r for r in test if r["canonical"]][40:120]:
    sid = f"group_{int(row['group_id'])}"
    for course, chart, _ in FR._official_charts(row):
        ev = sorted_hits(chart.events); vals = [self_sim_long(event_tokens(ev, chart.bpm))]
        for di, dv in enumerate((0.3, 0.6, 1.0), start=1):
            v, _ = apply_probe("C5_blandification", ev, dv, np.random.default_rng(0), chart.bpm, lm=lm, course=course)
            s = sealed[f"{sid}|{course}|C5_blandification|d{di}|r1"]; hf += FR._events_hash(v) != s[0]
            vals.append(self_sim_long(event_tokens(v, chart.bpm)))
        rho = 0.0 if len(set(vals)) == 1 else float(spearmanr([0, .3, .6, 1], vals).statistic)
        song[int(row["group_id"])].append((rho, vals[3] - vals[0])); offs.append(vals[0]); d3s.append(vals[3])
X = np.array([[np.mean([a for a, _ in v]), np.mean([b for _, b in v])] for v in song.values()])
B = X[np.random.default_rng(99).integers(0, len(X), size=(10000, len(X)))].mean(axis=1)
q = lambda c: [round(float(np.quantile(B[:, c], .0025)), 4), round(float(np.quantile(B[:, c], .9975)), 4)]
out = {"hash_fail": hf, "songs": len(X), "charts": len(offs), "rho": round(float(X[:, 0].mean()), 4), "rho_ci995": q(0),
       "delta": round(float(X[:, 1].mean()), 5), "delta_ci995": q(1),
       "chart_mean_official": round(float(np.mean(offs)), 5), "chart_mean_d3": round(float(np.mean(d3s)), 5)}
print(json.dumps(out)); (Path(__file__).parent / "selfsim_c5_verify.json").write_text(json.dumps(out, indent=1))
