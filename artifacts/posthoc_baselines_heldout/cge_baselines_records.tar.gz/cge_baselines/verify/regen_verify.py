"""ADVERSARIAL VERIFY (post-hoc secondary held-out baselines).

Independent of the scout's baseline_holdout.py / analyze_baselines.py:
- loads the test split with pyarrow (not `datasets`), audio column never read;
- takes RNG seeds from the sealed records (not derive_rng_seed);
- re-implements self-similarity (vectorised), IOI-histogram JS, onset F1 (greedy AND
  maximum-cardinality bipartite matching, mir_eval-style) from the definitions;
- only the frozen chart parser, tokeniser and edit operators are reused (unavoidable:
  they define the edits), and every regenerated variant is hash-checked against the
  sealed records.
Writes only to this verify/ directory. Repo imported read-only (PYTHONDONTWRITEBYTECODE=1).
"""
from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_bipartite_matching

REPO = Path("/Users/jacoblincool/Documents/GitHub/ChartGenEval")
EXP = REPO / "experiments/confirmatory_holdout_v1"
sys.path.insert(0, str(EXP))
sys.path.insert(0, str(REPO / "src"))
import run as FR  # noqa: E402
from chartgeneval.events import sorted_hits  # noqa: E402
from chartgeneval.metrics.common import event_tokens  # noqa: E402
from chartgeneval.probes import apply_probe  # noqa: E402

DATA = Path.home() / ".cache/huggingface/hub/datasets--JacobLinCool--taiko-1000-parsed-clean/snapshots/b72da4616d643018e81f372cea06ce51349285e0/data"
RAW = EXP / "runs/raw/confirmatory-primary-20260712/records.jsonl"
HERE = Path(__file__).resolve().parent
PROBES = {"C1_timing_jitter": (10, 20, 30), "C2_anchor_shift": (15, 30, 60), "C4_loop_collapse": (0.3, 0.6, 1.0)}


def self_sim_long(tokens, lo=12, hi=32, win=4):
    n = len(tokens) - win + 1
    if n < 2:
        return None
    ids = {}
    w = np.array([ids.setdefault(tuple(tokens[i:i + win]), len(ids)) for i in range(n)])
    best, found = 0.0, False
    for lag in range(lo, min(hi, n)):
        found = True
        best = max(best, float(np.mean(w[:-lag] == w[lag:])))
    return best if found else None


def ioi_js(tok_a, tok_b):
    a = Counter(t.split(":", 1)[0] for t in tok_a[1:])
    b = Counter(t.split(":", 1)[0] for t in tok_b[1:])
    keys = sorted(set(a) | set(b))
    p = np.array([a[k] for k in keys], float); q = np.array([b[k] for k in keys], float)
    if not keys or p.sum() == 0 or q.sum() == 0:
        return None
    p /= p.sum(); q /= q.sum(); m = (p + q) / 2
    kl = lambda x, y: float(np.sum(x[x > 0] * np.log2(x[x > 0] / y[x > 0])))
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def f1_greedy(ref, est, tol):
    ref = np.sort(np.asarray(ref)); est = np.sort(np.asarray(est))
    taken = np.zeros(len(ref), bool); m = 0
    for t in est:
        lo = np.searchsorted(ref, t - tol); hi = np.searchsorted(ref, t + tol)
        cand = [k for k in range(lo, hi) if not taken[k]]
        if cand:
            k = min(cand, key=lambda k: abs(ref[k] - t)); taken[k] = True; m += 1
    return 2 * m / (len(ref) + len(est)) if len(ref) + len(est) else 1.0


def f1_maxmatch(ref, est, tol):
    ref = np.asarray(ref); est = np.asarray(est)
    rows, cols = [], []
    order = np.argsort(est); es = est[order]
    for i, t in enumerate(ref):
        lo = np.searchsorted(es, t - tol, "left"); hi = np.searchsorted(es, t + tol, "right")
        for k in range(lo, hi):
            rows.append(i); cols.append(order[k])
    if not rows:
        return 0.0
    g = csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(len(ref), len(est)))
    m = int(np.sum(maximum_bipartite_matching(g, perm_type="column") >= 0))
    return 2 * m / (len(ref) + len(est))


def load_rows():
    cols = ["canonical", "group_id", "easy", "normal", "hard", "oni", "ura"]
    rows = []
    for f in ["test-00000-of-00002.parquet", "test-00001-of-00002.parquet"]:
        rows.extend(pq.read_table(DATA / f, columns=cols).to_pylist())
    canon = [r for r in rows if r["canonical"]]
    return [(ci, r) for ci, r in enumerate(canon) if 40 <= ci < 120], len(rows), len(canon)


def sealed_index():
    idx = {}
    with open(RAW) as fh:
        for line in fh:
            r = json.loads(line)
            idx[r["task_id"]] = (r["variant_events_sha256"], r["rng_seed"], r["status"], r["corruption_noop"],
                                 r["canonical_song_index"], r["group_id"])
    return idx


SEALED = None


def work(item):
    ci, row = item
    sid = f"group_{int(row['group_id'])}"
    out = []
    for course, chart, _cs in FR._official_charts(row):
        ev = sorted_hits(chart.events)
        base_tok = event_tokens(ev, chart.bpm)
        base_t = [t for t, _ in ev]
        cells = [("official", 0, 0, ev)]
        swap = {"don": "ka", "ka": "don", "don_big": "ka_big", "ka_big": "don_big"}
        for ri in range(1, 6):
            cells.append(("CTRL_color_bijection", 0, ri, [(t, swap[c]) for t, c in ev]))
            cells.append(("CTRL_joint_time_origin_shift", 0, ri, [(t + 1.0, c) for t, c in ev]))
        for probe, doses in PROBES.items():
            for di, dv in enumerate(doses, start=1):
                for ri in range(1, 6):
                    s = SEALED[f"{sid}|{course}|{probe}|d{di}|r{ri}"]
                    rng = np.random.default_rng(s[1])
                    v, _noop = apply_probe(probe, ev, dv, rng, chart.bpm)
                    cells.append((probe, di, ri, v))
        for cond, di, ri, v in cells:
            tid = f"{sid}|{course}|{cond}|d{di}|r{ri}"
            s = SEALED[tid]
            tok = event_tokens(v, chart.bpm)
            vt = [t for t, _ in sorted_hits(v)]
            ref_t = [t + 1.0 for t in base_t] if cond == "CTRL_joint_time_origin_shift" else base_t
            out.append({
                "task_id": tid, "group_id": int(row["group_id"]), "canonical_song_index": ci, "course": course,
                "condition": cond, "dose_index": di, "replicate_index": ri,
                "hash_ok": FR._events_hash(v) == s[0], "status": s[2], "noop": s[3],
                "sealed_csi_ok": s[4] == ci and s[5] == int(row["group_id"]),
                "tokens_equal_official": tok == base_tok,
                "self_sim_long": self_sim_long(tok),
                "ioi_js": ioi_js(tok, base_tok),
                "f1g50": f1_greedy(ref_t, vt, 0.05), "f1g20": f1_greedy(ref_t, vt, 0.02),
                "f1m50": f1_maxmatch(ref_t, vt, 0.05), "f1m20": f1_maxmatch(ref_t, vt, 0.02),
            })
    return out


def init():
    global SEALED
    SEALED = sealed_index()


if __name__ == "__main__":
    items, n_rows, n_canon = load_rows()
    print(json.dumps({"test_rows": n_rows, "canonical": n_canon, "heldout_songs": len(items)}))
    with Pool(6, initializer=init) as pool:
        res = [r for chunk in pool.imap(work, items, chunksize=2) for r in chunk]
    with open(HERE / "regen_records.jsonl", "w") as fh:
        for r in res:
            fh.write(json.dumps(r) + "\n")
    print(json.dumps({"records": len(res), "hash_fail": sum(not r["hash_ok"] for r in res),
                      "csi_fail": sum(not r["sealed_csi_ok"] for r in res),
                      "charts": len({(r['group_id'], r['course']) for r in res})}))
