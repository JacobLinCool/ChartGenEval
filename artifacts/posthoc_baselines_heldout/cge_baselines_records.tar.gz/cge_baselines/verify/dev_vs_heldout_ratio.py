"""Compare development (+62% self-sim, 9.44->5.98 ppl) aggregation with held-out, same aggregation."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
A = Path("/Users/jacoblincool/Documents/GitHub/ChartGenEval/artifacts/records/corruption_borrowed_metrics_clean.jsonl")
rows = [json.loads(l) for l in open(A)]
print("dev keys:", sorted(rows[0].keys())[:30])
def get(r, k):
    m = r.get("metrics", r)
    return m.get(k)
cond_key = next(k for k in ("probe", "condition", "corruption") if k in rows[0])
dose_key = next(k for k in ("dose", "dose_index", "dose_idx") if k in rows[0])
print("cond/dose keys:", cond_key, dose_key, {r[cond_key] for r in rows})
off = {(r["sid"], r["course"]): r for r in rows if r[cond_key] in ("official", "none", None, "clean")}
out = {}
for metric, probe in (("structureness_indicator_long", "C4_loop_collapse"), ("pattern_ngram_perplexity", "C5_blandification")):
    pairs = [(get(off[(r["sid"], r["course"])], metric), get(r, metric)) for r in rows
             if r[cond_key] == probe and int(r[dose_key]) == 3 and (r["sid"], r["course"]) in off]
    pairs = [(a, b) for a, b in pairs if a is not None and b is not None]
    a = np.array(pairs)
    out[f"dev|{metric}|{probe}|d3"] = {"n": len(a), "chart_mean_official": float(a[:, 0].mean()), "chart_mean_d3": float(a[:, 1].mean()),
                                       "ratio_of_means": float(a[:, 1].mean() / a[:, 0].mean() - 1)}
# held-out, same chart-mean aggregation (self-sim from verify regen; C4 deterministic so seed-mean == each seed)
reg = [json.loads(l) for l in open(Path(__file__).parent / "regen_records.jsonl")]
o = {(r["group_id"], r["course"]): r["self_sim_long"] for r in reg if r["condition"] == "official"}
d3 = defaultdict(list)
for r in reg:
    if r["condition"] == "C4_loop_collapse" and r["dose_index"] == 3:
        d3[(r["group_id"], r["course"])].append(r["self_sim_long"])
ks = [k for k in o if o[k] is not None and k in d3 and all(v is not None for v in d3[k])]
a = np.array([(o[k], np.mean(d3[k])) for k in ks])
out["heldout|self_sim_long|C4|d3"] = {"n": len(a), "chart_mean_official": float(a[:, 0].mean()), "chart_mean_d3": float(a[:, 1].mean()),
                                      "ratio_of_means": float(a[:, 1].mean() / a[:, 0].mean() - 1)}
print(json.dumps(out, indent=1))
(Path(__file__).parent / "dev_vs_heldout_ratio.json").write_text(json.dumps(out, indent=1))
