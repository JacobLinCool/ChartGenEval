"""POST-HOC SECONDARY held-out baseline analysis (not preregistered).

Spec: SPEC_posthoc_baselines.md (written before this script ran).
Imports the frozen confirmatory analysis functions read-only
(PYTHONDONTWRITEBYTECODE=1 must be set). Writes only into this scratch dir.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

REPO = Path("/Users/jacoblincool/Documents/GitHub/ChartGenEval")
EXP = REPO / "experiments/confirmatory_holdout_v1"
RUN = EXP / "runs/raw/confirmatory-primary-20260712"
TABLES = RUN / "tables"
PRIMARY = REPO / "artifacts/confirmatory_holdout_v1/primary_results.json"
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(EXP))
sys.path.insert(0, str(REPO / "src"))

import analyze as FA  # noqa: E402  frozen analysis, read-only


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read_jsonl(p: Path) -> list[dict]:
    with open(p) as fh:
        return [json.loads(line) for line in fh if line.strip()]


contract = json.load(open(RUN / "spec_snapshots/contract.json"))
acfg = contract["analysis"]
DRAWS = int(acfg["bootstrap_draws"])
NOM = float(acfg["nominal_confidence_level"])
ADJ = float(acfg["familywise_confidence_level"])
MIN_G = int(acfg["minimum_confirmatory_group_clusters"])
MASTER = int(acfg["bootstrap_seed"])
ADJ_KEY = f"{ADJ:.6f}"


def verdict_of(summary, controls_pass):
    if not controls_pass or summary["n_group_clusters"] < MIN_G:
        return "INCONCLUSIVE"
    d_lo, d_hi = summary["confidence_intervals"][ADJ_KEY]["dose_statistic"]
    c_lo, c_hi = summary["confidence_intervals"][ADJ_KEY]["target_minus_sham"]
    if d_hi < 0.0 and c_hi < 0.0:
        return "SURVIVES"
    if d_lo >= 0.0 or c_lo >= 0.0:
        return "REFUTED"
    return "INCONCLUSIVE"


# ---------------------------------------------------------------- step 1: validate harness
observations = read_jsonl(TABLES / "observations.jsonl")
frozen_means = read_jsonl(TABLES / "chart_dose_means.jsonl")
index = FA._index_means(frozen_means)
_, ctrl_pass, ctrl_course = FA._control_diagnostics(observations, contract)
sealed_primary = {r["pair_id"]: r for r in json.load(open(PRIMARY))}
validation = []
for pair in contract["primary_pairs"]:
    gv, _ex, cc = FA._pair_group_values(index, pair, contract, ctrl_course)
    s = FA._cluster_summary(gv, draws=DRAWS, seed=FA._pair_seed(MASTER, pair["pair_id"]), levels=(NOM, ADJ))
    req = [(c, pair["metric"]) for c, ctl in contract["controls"].items()
           if pair["family"] in ctl["scoped_families"] and pair["metric"] in ctl["metrics"]]
    v = verdict_of(s, all(ctrl_pass.get(k, False) for k in req))
    ref = sealed_primary[pair["pair_id"]]
    ok = (
        s["dose_statistic_mean"] == ref["dose_statistic_mean"]
        and s["target_minus_sham_mean"] == ref["target_minus_sham_mean"]
        and s["confidence_intervals"] == ref["confidence_intervals"]
        and s["n_group_clusters"] == ref["n_group_clusters"]
        and len(cc) == ref["n_complete_courses"]
        and v == ref["verdict"]
    )
    validation.append({"pair_id": pair["pair_id"], "exact_match": ok, "verdict": v,
                       "dose_statistic_mean": s["dose_statistic_mean"],
                       "target_minus_sham_mean": s["target_minus_sham_mean"],
                       "ci995": s["confidence_intervals"][ADJ_KEY], "n": s["n_group_clusters"]})
if not all(r["exact_match"] for r in validation):
    print(json.dumps(validation, indent=1))
    raise SystemExit("VALIDATION FAILED: frozen primary rows not reproduced")
print("validation: all 10 frozen primary rows reproduced exactly")

# ---------------------------------------------------------------- step 2: load baseline records
shards = sorted((HERE / "full").glob("shard_*.jsonl"))
brecs = []
for p in shards:
    brecs.extend(read_jsonl(p))
if len(brecs) != 50283:
    raise SystemExit(f"record count {len(brecs)} != 50283")
if not all(r["sealed_hash_match"] and r["sealed_pattern_nll_match"] for r in brecs):
    raise SystemExit("sealed hash / pattern_nll mismatch present")
bidx = {}
for r in brecs:
    gid = int(r["sid"].split("_")[1])
    k = (gid, r["course"], r["condition"], int(r["dose_index"]), int(r["replicate_index"]))
    if k in bidx:
        raise SystemExit(f"duplicate baseline key {k}")
    bidx[k] = r

BASELINES = {
    # key: (field, worse-direction, chart_only, time_only)
    "lm_perplexity": ("lm_perplexity", "increase", True, False),
    "self_similarity": ("self_similarity_si_long", "decrease", True, False),
    "ioi_hist_js": ("ioi_hist_js_vs_ref_bits", "increase", True, True),
    "onset_f1_50ms": ("onset_f1_vs_ref_50ms", "decrease", False, True),
    "onset_f1_20ms": ("onset_f1_vs_ref_20ms", "decrease", False, True),
}
TOL = 1e-9

# baseline observations: frozen status/noop, baseline metrics
bobs = []
for o in observations:
    k = (int(o["group_id"]), o["course"], o["condition"], int(o["dose_index"]), int(o["replicate_index"]))
    r = bidx.get(k)
    if r is None or r["variant_events_sha256"] != o["variant_events_sha256"]:
        raise SystemExit(f"observation without matching baseline record: {k}")
    m = {b: r["metrics"].get(f) for b, (f, *_rest) in BASELINES.items()}
    bobs.append({**o, "metrics": m})
if len(bobs) != len(bidx):
    raise SystemExit("baseline records not 1:1 with sealed observations")

# chart-dose means with the frozen replicate reducer rule
grouped = defaultdict(list)
for o in bobs:
    grouped[(int(o["group_id"]), o["course"], o["condition"], int(o["dose_index"]))].append(o)
bmeans = []
for k, rows in sorted(grouped.items()):
    expected = 1 if rows[0]["condition_kind"] == "official" else 5
    assert len(rows) == expected, k
    usable = [r for r in rows if r["status"] == "success" and not r["corruption_noop"]]
    mm = {}
    for b in BASELINES:
        vals = [float(r["metrics"][b]) for r in usable if r["metrics"].get(b) is not None]
        mm[b] = float(np.mean(vals)) if len(vals) == expected else None
    bmeans.append({"group_id": k[0], "course": k[1], "condition": k[2], "dose_index": k[3],
                   "status": "valid" if len(usable) == expected else "invalid", "metrics": mm})
# status must equal the frozen table's status for every key
fstat = {(int(r["group_id"]), r["course"], r["condition"], int(r["dose_index"])): r["status"] for r in frozen_means}
bstat = {(r["group_id"], r["course"], r["condition"], r["dose_index"]): r["status"] for r in bmeans}
if fstat != bstat:
    raise SystemExit("chart-dose status differs from frozen table")
bindex = FA._index_means(bmeans)

# baseline control contract: family per baseline = "bl_<name>"
bcontract = {"probes": contract["probes"], "controls": {}, "control_absolute_tolerances": {b: TOL for b in BASELINES}}
for cid in ("CTRL_identity", "CTRL_joint_time_origin_shift", "CTRL_color_bijection", "C2_anchor_shift"):
    fams, mets = [], []
    for b, (_f, _d, chart_only, time_only) in BASELINES.items():
        need = (cid in ("CTRL_identity", "CTRL_joint_time_origin_shift")
                or (cid == "C2_anchor_shift" and chart_only)
                or (cid == "CTRL_color_bijection" and time_only))
        if need:
            fams.append(f"bl_{b}"); mets.append(b)
    bcontract["controls"][cid] = {"scoped_families": fams, "metrics": mets}
bdiag, bpass, bcourse = FA._control_diagnostics(bobs, bcontract)

# unrestricted diagnostics (every control x every baseline) for the report
all_ctrl = {"probes": contract["probes"], "control_absolute_tolerances": {b: TOL for b in BASELINES},
            "controls": {c: {"scoped_families": [], "metrics": list(BASELINES)} for c in
                         ("CTRL_identity", "CTRL_joint_time_origin_shift", "CTRL_color_bijection", "C2_anchor_shift")}}
alldiag, _, _ = FA._control_diagnostics(bobs, all_ctrl)

FROZEN_SHAM = {}
for p in contract["primary_pairs"]:
    FROZEN_SHAM[p["probe"]] = (p["scoped_sham"], int(p["scoped_sham_dose_index"]))
EDITS = list(contract["probes"])  # 9 edits, frozen order

results = []
for b, (field, worse, chart_only, time_only) in BASELINES.items():
    fam = f"bl_{b}"
    required = [(c, b) for c, ctl in bcontract["controls"].items() if fam in ctl["scoped_families"]]
    controls_pass = all(bpass.get(k, False) for k in required)
    for probe in EDITS:
        sham, sham_dose = FROZEN_SHAM[probe]
        sham_rule = "frozen"
        if not any(c == sham for c, _ in required):
            sham, sham_dose, sham_rule = "CTRL_identity", 0, "identity_fallback"
        pair = {"pair_id": f"POSTHOC_BASELINE__{probe}__{b}", "probe": probe, "metric": b, "family": fam,
                "expected_raw_direction": worse, "scoped_sham": sham, "scoped_sham_dose_index": sham_dose}
        gv, ex, cc = FA._pair_group_values(bindex, pair, bcontract, bcourse)
        s = FA._cluster_summary(gv, draws=DRAWS, seed=FA._pair_seed(MASTER, pair["pair_id"]), levels=(NOM, ADJ))
        v = verdict_of(s, controls_pass)
        ci = s["confidence_intervals"].get(ADJ_KEY, {})
        vals = np.asarray(list(gv.values()), dtype=float) if gv else np.zeros((0, 2))
        all_zero = bool(len(vals)) and bool(np.all(vals == 0.0))
        # replicate-level exact invariance: every seed at every dose equals the unedited value
        # (the 5-seed mean can differ from the unedited value by 1 ulp, which the rank statistic sees)
        rep_invariant = bool(cc) and all(
            bidx[(gid, course, probe, di, ri)]["metrics"][field] == bidx[(gid, course, "official", 0, 0)]["metrics"][field]
            for gid, course in cc for di in (1, 2, 3) for ri in range(1, 6))
        if not controls_pass:
            label = "control-fail"
        elif v == "SURVIVES":
            label = "detects"
        elif all_zero or rep_invariant:
            label = "blind"
        elif ci and (ci["dose_statistic"][0] > 0 or ci["target_minus_sham"][0] > 0):
            label = "rewards"
        else:
            label = "misses"
        # raw signed descriptive: song-mean of (strongest dose - official), un-oriented
        raw = defaultdict(list)
        for gid, course in cc:
            raw[gid].append(bindex[(gid, course, probe, 3)]["metrics"][b] - bindex[(gid, course, "official", 0)]["metrics"][b])
        raw_delta = float(np.mean([np.mean(v_) for v_ in raw.values()])) if raw else None
        base_vals = defaultdict(list)
        for gid, course in cc:
            base_vals[gid].append(bindex[(gid, course, "official", 0)]["metrics"][b])
        base_mean = float(np.mean([np.mean(v_) for v_ in base_vals.values()])) if base_vals else None
        results.append({
            "analysis": "POST_HOC_SECONDARY_heldout_baselines", "baseline": b, "field": field,
            "worse_direction": worse, "probe": probe, "sham": f"{sham}:d{sham_dose}", "sham_rule": sham_rule,
            "required_controls": [c for c, _ in required], "controls_pass": controls_pass,
            "n_songs": s["n_group_clusters"], "n_courses": len(cc), "n_excluded_courses": len(ex),
            "dose_statistic_mean": s["dose_statistic_mean"], "dose_ci995": ci.get("dose_statistic"),
            "contrast_mean": s["target_minus_sham_mean"], "contrast_ci995": ci.get("target_minus_sham"),
            "all_song_values_exactly_zero": all_zero, "replicate_level_exactly_invariant": rep_invariant, "frozen_rule_verdict": v, "label": label,
            "raw_strongest_minus_official_song_mean": raw_delta, "official_song_mean": base_mean,
        })

out = {
    "analysis": "POST_HOC_SECONDARY_heldout_baselines (not preregistered; held-out labels already opened)",
    "spec": {"file": "SPEC_posthoc_baselines.md", "sha256": sha(HERE / "SPEC_posthoc_baselines.md")},
    "inputs": {
        "observations.jsonl": sha(TABLES / "observations.jsonl"),
        "chart_dose_means.jsonl": sha(TABLES / "chart_dose_means.jsonl"),
        "contract.json": sha(RUN / "spec_snapshots/contract.json"),
        "primary_results.json": sha(PRIMARY),
        "analyze.py": sha(EXP / "analyze.py"),
        **{p.name: sha(p) for p in shards},
    },
    "validation_frozen_rows": validation,
    "n_baseline_records": len(brecs),
    "control_diagnostics_required": bdiag,
    "control_diagnostics_all": alldiag,
    "results": results,
}
(HERE / "baseline_heldout_results.json").write_text(json.dumps(out, indent=1))
with open(HERE / "baseline_heldout_results.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(results[0]))
    w.writeheader()
    for r in results:
        w.writerow({k: json.dumps(v) if isinstance(v, list) else v for k, v in r.items()})


def f(x, n=3):
    return "NA" if x is None else f"{x:+.{n}f}"


for r in results:
    d = r["dose_ci995"] or [None, None]; c = r["contrast_ci995"] or [None, None]
    print(f"{r['baseline']:16s} {r['probe']:18s} rho {f(r['dose_statistic_mean'])} [{f(d[0])},{f(d[1])}]  "
          f"dlt {f(r['contrast_mean'],4)} [{f(c[0],4)},{f(c[1],4)}] n={r['n_songs']:2d} {r['frozen_rule_verdict']:12s} {r['label']:12s} "
          f"raw {f(r['raw_strongest_minus_official_song_mean'],4)} base {f(r['official_song_mean'],3)} sham={r['sham']}")
print("controls (required):")
for d in bdiag:
    print(" ", d["control"], d["metric"], "max", d["max_absolute_delta"], "pass", d["passes"], d["n_evaluable_control_replicates"], "/", d["n_expected_control_replicates"])
print("controls (all, descriptive):")
for d in alldiag:
    print(" ", d["control"], d["metric"], "max", d["max_absolute_delta"], "pass", d["passes"])
