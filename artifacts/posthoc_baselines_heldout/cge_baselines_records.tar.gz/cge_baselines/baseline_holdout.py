"""POST-HOC SECONDARY held-out baseline-metric computation (not preregistered).

Regenerates the frozen confirmatory_holdout_v1 variants (same contract, seeds,
probe code, LM) for canonical songs in [start, stop), byte-verifies every
variant against the sealed raw records (variant_events_sha256,
input_chart_sha256, pattern_nll), and computes common baseline metrics.
Writes only to this scratch directory. Imports the ChartGenEval repo read-only
(PYTHONDONTWRITEBYTECODE=1 must be set by the caller).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

REPO = Path("/Users/jacoblincool/Documents/GitHub/ChartGenEval")
EXP = REPO / "experiments/confirmatory_holdout_v1"
SOFTCHART = Path("/Users/jacoblincool/Documents/GitHub/SoftChart")
sys.path.insert(0, str(EXP))
sys.path.insert(0, str(REPO / "src"))

import run as frozen_run  # noqa: E402  (read-only import of frozen runner)
from contract import derive_rng_seed, load_contract, load_json  # noqa: E402
from chartgeneval.events import sorted_hits  # noqa: E402
from chartgeneval.metrics.common import NGramModel, compute_chart_features, event_tokens, _relative_times  # noqa: E402
from chartgeneval.probes import apply_probe  # noqa: E402

DATA = Path.home() / ".cache/huggingface/hub/datasets--JacobLinCool--taiko-1000-parsed-clean/snapshots/b72da4616d643018e81f372cea06ce51349285e0/data"
RAW = EXP / "runs/raw/confirmatory-primary-20260712/records.jsonl"
RUN_MANIFEST = EXP / "runs/raw/confirmatory-primary-20260712/MANIFEST.json"


# ---- baseline metric functions: verbatim copies of SoftChart
# scripts/run/metric_baselines_eval.py (structureness_indicator, distinct_n,
# groove_consistency, empty_beat_rate) and src/softchart/evaluate.py
# (match_onsets, onset_prf); sha256 of source files recorded in output.

def distinct_n(tokens, n):
    if len(tokens) < n:
        return None
    grams = [tuple(tokens[i: i + n]) for i in range(len(tokens) - n + 1)]
    if not grams:
        return None
    return float(len(set(grams)) / len(grams))


def structureness_indicator(tokens, short_range=(4, 12), long_range=(12, 32)):
    win = 4
    windows = [tuple(tokens[i: i + win]) for i in range(len(tokens) - win + 1)]
    n = len(windows)
    if n < 2:
        return None, None

    def band_max(lo, hi):
        best = 0.0
        found = False
        for lag in range(lo, min(hi, n)):
            same = 0
            total = 0
            for i in range(n - lag):
                total += 1
                if windows[i] == windows[i + lag]:
                    same += 1
            if total > 0:
                found = True
                best = max(best, same / total)
        return best if found else None

    return band_max(*short_range), band_max(*long_range)


def groove_consistency(events, bpm, subdiv=16):
    hits = sorted_hits(events)
    times = _relative_times([t for t, _ in hits])
    if len(times) < 2 or not bpm or bpm <= 0:
        return None
    beat_s = 60.0 / bpm
    measure_s = 4.0 * beat_s
    slot_s = measure_s / subdiv
    t0 = float(times[0])
    span = float(times[-1] - t0)
    n_measures = int(math.floor(span / measure_s)) + 1
    if n_measures < 2:
        return None
    grids = np.zeros((n_measures, subdiv), dtype=np.int8)
    for t in times:
        rel = float(t) - t0
        m = int(math.floor(rel / measure_s))
        if m < 0 or m >= n_measures:
            continue
        slot = int(round((rel - m * measure_s) / slot_s)) % subdiv
        grids[m, slot] = 1
    hammings = [float(np.sum(grids[i] != grids[i + 1])) / subdiv for i in range(n_measures - 1)]
    if not hammings:
        return None
    return float(1.0 - np.mean(hammings))


def empty_beat_rate(events, bpm):
    hits = sorted_hits(events)
    times = _relative_times([t for t, _ in hits])
    if len(times) < 2 or not bpm or bpm <= 0:
        return None
    beat_s = 60.0 / bpm
    t0 = float(times[0])
    span = float(times[-1] - t0)
    n_beats = int(math.floor(span / beat_s)) + 1
    if n_beats <= 0:
        return None
    occupied = set()
    for t in times:
        b = int(math.floor((float(t) - t0) / beat_s))
        if 0 <= b < n_beats:
            occupied.add(b)
    return float((n_beats - len(occupied)) / n_beats)


def match_onsets(ref_times, est_times, tol=0.05):
    matches = []
    ref = np.asarray(ref_times)
    est = np.asarray(est_times)
    order = np.argsort(est)
    ref_order = np.argsort(ref)
    ref_sorted = ref[ref_order]
    taken = np.zeros(len(ref), dtype=bool)
    for e_i in order:
        t = est[e_i]
        lo = np.searchsorted(ref_sorted, t - tol)
        hi = np.searchsorted(ref_sorted, t + tol)
        best, best_d = -1, tol + 1
        for k in range(lo, hi):
            rid = ref_order[k]
            if taken[rid]:
                continue
            d = abs(ref_sorted[k] - t)
            if d < best_d:
                best, best_d = rid, d
        if best >= 0:
            taken[best] = True
            matches.append((int(best), int(e_i)))
    return matches


def onset_f1(ref_times, est_times, tol=0.05):
    if len(ref_times) == 0 and len(est_times) == 0:
        return 1.0
    if len(ref_times) == 0 or len(est_times) == 0:
        return 0.0
    m = len(match_onsets(ref_times, est_times, tol))
    p = m / len(est_times)
    r = m / len(ref_times)
    return 2 * p * r / (p + r) if p + r > 0 else 0.0


def ioi_hist(tokens):
    return Counter(tok.split(":", 1)[0] for tok in tokens[1:])


def js_divergence_bits(p_counts, q_counts):
    keys = sorted(set(p_counts) | set(q_counts))
    if not keys:
        return None
    p = np.array([p_counts.get(k, 0) for k in keys], dtype=float)
    q = np.array([q_counts.get(k, 0) for k in keys], dtype=float)
    if p.sum() == 0 or q.sum() == 0:
        return None
    p /= p.sum(); q /= q.sum(); m = 0.5 * (p + q)

    def kl(a, b):
        mask = a > 0
        return float(np.sum(a[mask] * np.log2(a[mask] / b[mask])))

    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def baseline_metrics(events, bpm, course, lm, ref_events, ref_tokens):
    tokens = event_tokens(events, bpm)
    stats = lm.sequence_stats(course, tokens)
    nll = stats.get("pattern_nll")
    feats = compute_chart_features(events, bpm)
    si_s, si_l = structureness_indicator(tokens)
    hits = sorted_hits(events)
    ref_hits = sorted_hits(ref_events)
    return {
        "pattern_nll": nll,
        "lm_perplexity": float(math.exp(nll)) if nll is not None else None,
        "self_similarity_si_long": si_l,
        "self_similarity_si_short": si_s,
        "distinct_2": distinct_n(tokens, 2),
        "distinct_4": distinct_n(tokens, 4),
        "type_token_ratio": (len(set(tokens)) / len(tokens)) if tokens else None,
        "ioi_entropy_bits": feats.get("ioi_entropy_bits"),
        "ioi_cv": feats.get("ioi_cv"),
        "ioi_hist_js_vs_ref_bits": js_divergence_bits(ioi_hist(tokens), ioi_hist(ref_tokens)),
        "empty_beat_rate": empty_beat_rate(events, bpm),
        "groove_consistency": groove_consistency(events, bpm),
        "onset_f1_vs_ref_50ms": onset_f1([t for t, _ in ref_hits], [t for t, _ in hits], 0.05),
        "onset_f1_vs_ref_20ms": onset_f1([t for t, _ in ref_hits], [t for t, _ in hits], 0.02),
    }


def iter_test_rows(start, stop):
    from datasets import Audio, load_dataset
    files = [str(DATA / "test-00000-of-00002.parquet"), str(DATA / "test-00001-of-00002.parquet")]
    ds = load_dataset("parquet", data_files={"test": files}, split="test", streaming=True)
    ds = ds.cast_column("audio", Audio(decode=False))
    canonical_index = 0
    for raw_index, row in enumerate(ds):
        if not row["canonical"]:
            continue
        if start <= canonical_index < stop:
            yield raw_index, canonical_index, row
        canonical_index += 1
        if canonical_index >= stop:
            return


def train_lm(contract):
    from datasets import load_dataset
    lm_c = contract["language_model"]
    lm = NGramModel(order=int(lm_c["order"]), alpha=float(lm_c["alpha"]))
    files = sorted(str(p) for p in DATA.glob("train-*.parquet"))
    cols = ["tja", "oni", "hard", "normal", "easy", "metadata", "ura", "group_id", "canonical", "audio_sha256"]
    ds = load_dataset("parquet", data_files={"train": files}, split="train", streaming=True, columns=cols)
    n_rows = n_charts = 0
    for row in ds:
        n_rows += 1
        for course, chart, _cs in frozen_run._official_charts(row):
            lm.add(course, event_tokens(chart.events, chart.bpm))
            n_charts += 1
    return lm, n_rows, n_charts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=40)
    ap.add_argument("--stop", type=int, default=42)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    t0 = time.time()
    config, contract, _, _ = load_contract(EXP / "configs/confirmatory.json")

    # sealed raw index: task key -> (variant hash, input hash, pattern_nll)
    sealed = {}
    with open(RAW) as fh:
        for line in fh:
            r = json.loads(line)
            if args.start <= r["canonical_song_index"] < args.stop:
                sealed[(r["sid"], r["task_id"])] = (
                    r["variant_events_sha256"], r["input_chart_sha256"], r["metrics"].get("pattern_nll"))
    t_sealed = time.time()

    lm, n_rows, n_charts = train_lm(contract)
    lm_fp = frozen_run._lm_state_fingerprint(lm)
    manifest = load_json(RUN_MANIFEST)
    t_lm = time.time()

    seeds = contract["replicate_base_seeds"]
    n = mism = nll_mism = 0
    out_path = Path(args.out)
    with open(out_path, "w") as out:
        for raw_index, cidx, row in iter_test_rows(args.start, args.stop):
            sid = f"group_{int(row['group_id'])}"
            for course, chart, course_struct in frozen_run._official_charts(row):
                events = sorted_hits(chart.events)
                segments = (course_struct or {}).get("segments") or []
                grid = {"segments": segments} if segments else None
                duration = (events[-1][0] + 1.0) if events else 0.0
                input_hash = frozen_run._chart_input_hash(course, chart, course_struct)
                ref_tokens = event_tokens(events, chart.bpm)
                cells = [("official", 0, 0, 0, events)]
                for ctrl in ("CTRL_identity", "CTRL_joint_time_origin_shift", "CTRL_color_bijection"):
                    for ri, _bs in enumerate(seeds, start=1):
                        ev, _g, _d = frozen_run._control_variant(ctrl, events, grid, duration)
                        cells.append((ctrl, 0, 0, ri, ev))
                for probe_id, pc in contract["probes"].items():
                    for di, dv in enumerate(pc["dose_values"], start=1):
                        for ri, bs in enumerate(seeds, start=1):
                            rng = np.random.default_rng(derive_rng_seed(bs, sid, course, probe_id, di))
                            ev, _noop = apply_probe(probe_id, events, dv, rng, chart.bpm, lm=lm, course=course)
                            cells.append((probe_id, di, dv, ri, ev))
                for cond, di, dv, ri, ev in cells:
                    task_id = f"{sid}|{course}|{cond}|d{di}|r{ri}"
                    vh = frozen_run._events_hash(ev)
                    s = sealed.get((sid, task_id))
                    ok = s is not None and s[0] == vh and s[1] == input_hash
                    ref_ev = [(t + 1.0, c) for t, c in events] if cond == "CTRL_joint_time_origin_shift" else events
                    m = baseline_metrics(ev, chart.bpm, course, lm, ref_ev, ref_tokens)
                    nll_ok = s is not None and s[2] is not None and m["pattern_nll"] is not None and abs(s[2] - m["pattern_nll"]) <= 1e-12
                    mism += (not ok); nll_mism += (not nll_ok); n += 1
                    out.write(json.dumps({
                        "analysis": "POST_HOC_SECONDARY_heldout_baselines",
                        "sid": sid, "canonical_song_index": cidx, "course": course,
                        "condition": cond, "dose_index": di, "dose_value": dv, "replicate_index": ri,
                        "task_id": task_id, "variant_events_sha256": vh,
                        "sealed_hash_match": ok, "sealed_pattern_nll_match": nll_ok,
                        "metrics": m}) + "\n")
    t_end = time.time()
    print(json.dumps({
        "records": n, "sealed_hash_mismatches": mism, "pattern_nll_mismatches": nll_mism,
        "sealed_records_in_range": len(sealed),
        "lm_train_rows": n_rows, "lm_train_charts": n_charts,
        "lm_state_sha256": lm_fp,
        "run_manifest_contains_lm_fp": lm_fp in json.dumps(manifest),
        "sec_index_sealed": round(t_sealed - t0, 1), "sec_lm": round(t_lm - t_sealed, 1),
        "sec_score": round(t_end - t_lm, 1),
        "softchart_baselines_sha256": hashlib.sha256((SOFTCHART / "scripts/run/metric_baselines_eval.py").read_bytes()).hexdigest(),
        "softchart_evaluate_sha256": hashlib.sha256((SOFTCHART / "src/softchart/evaluate.py").read_bytes()).hexdigest(),
    }, indent=1))


if __name__ == "__main__":
    main()
