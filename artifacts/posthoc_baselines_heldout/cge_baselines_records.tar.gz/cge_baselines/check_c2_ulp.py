"""Diagnose nonzero C2 dose statistic for chart-only baselines: replicate-level identity vs mean-reducer rounding."""
import json, glob
from collections import defaultdict
import numpy as np
recs=[json.loads(l) for p in sorted(glob.glob('full/shard_*.jsonl')) for l in open(p)]
by=defaultdict(dict)
for r in recs:
    by[(r['sid'],r['course'])][(r['condition'],r['dose_index'],r['replicate_index'])]=r['metrics']
out={}
for f in ['lm_perplexity','self_similarity_si_long']:
    rep_max=0.0; mean_nonzero=0; charts=0; mean_max=0.0
    for k,d in by.items():
        base=d[('official',0,0)][f]
        if base is None: continue
        charts+=1
        for di in (1,2,3):
            vals=[d[('C2_anchor_shift',di,ri)][f] for ri in range(1,6)]
            rep_max=max(rep_max,max(abs(v-base) for v in vals))
            m=float(np.mean(vals))
            if m!=base: mean_nonzero+=1; mean_max=max(mean_max,abs(m-base)/abs(base) if base else abs(m))
    out[f]={'charts':charts,'replicate_level_max_abs_delta':rep_max,'chart_dose_means_differing_from_official':mean_nonzero,'max_relative_diff_of_mean':mean_max}
print(json.dumps(out,indent=1))
